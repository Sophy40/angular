export const environment = {
  production: true,
  appTitle:'Expertzlab'
};
