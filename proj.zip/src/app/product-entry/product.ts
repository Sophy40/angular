import { StringMap } from "@angular/compiler/src/compiler_facade_interface";
import { PLATFORM_ID } from '@angular/core';

export class Product{
    pid
    pname
    
    
        
    
    constructor(pid:string,name:StringMap){
        this.pid=pid
        this.pname=name
}}