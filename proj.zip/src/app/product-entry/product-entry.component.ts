import { Component, OnInit } from '@angular/core';
import { Product } from './product'
import { ProductService } from '../product.service';
@Component({
  selector: 'app-product-entry',
  templateUrl: './product-entry.component.html',
  styleUrls: ['./product-entry.component.css']
})
export class ProductEntryComponent implements OnInit {
  productArray: Product[] = <any><Product[]>[]
  done = false
  disabled = true

  condition=true
  text = "welcome"
  myColor = 're d'
  myFont = 'bold'
  blueBold = 'blueBold'
  blueBolddisabled = 'blueBolddisabled'
  myStyle = { 'color': this.myColor, 'font-weight': this.myFont }
  // obj={'greenBold':true,'blueBold':false}
  obj={greenBold:false, blueBold:false}
  as1=''
_prodServices:ProductService
pList:any
  constructor(prodServices:ProductService) { 
   this._prodServices =prodServices
  }

  ngOnInit() {
 this.pList= this._prodServices.getProdlist().subscribe()
  }
  saveProduct(pid, pname) {
    let product = new Product(pid, pname)

    console.log(pid, pname)
    this.productArray.push(product)
  }
  updateStyle() {
    // this.myStyle = { 'color': this.myColor, 'font-weight': this.myFont }
if(this.as1=='green')
  {
    this.obj.greenBold=true
    this.obj.blueBold=false
  }else{
    this.obj.greenBold=false
    this.obj.blueBold=true
  }
}
} 