import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { interval } from 'rxjs';
import { filter ,tap,map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
       http:HttpClient

  constructor(http:HttpClient) {
    this.http=http
   }
   getProdlist(){
     
   return this.http.get('http://localhost:4200/assets/product.json')
   .pipe(
     map((data:any[])=>{
       const ndata=[]
       data.forEach((el)=>{
         console.log('El:',el)
         const sid=  'S-'+el.id
         const sname ='S-'+ el.name
         //data.splice(el,1)
         ndata.push({
           'id':sid,
           'name': sname
         })
       })
       return ndata
     })
     ,tap((data) => {
       console.log('received from server:',data)
     })
   )
    }
  }
  //  interval(1000).pipe(
  //    filter(num=> (num %2) === 0),
  //    map(num => num * num)
  //  ).subscribe(
  //    val=>{
  //      console.log(val)
  //    }
  //    )
  //   }

     //}
  
   
  
